const selectFrom = document.querySelector('#selectFrom');
const selectTo = document.querySelector('#selectTo');
const convertBtn = document.querySelector('#convertBtn');
const inputFrom = document.querySelector('#inputFrom');
const output = document.querySelector('#output');
const cancel = document.getElementById('cancel');
const inputField = document.getElementById('inputField');

// Convert Decimal to Binary, Octal, Hexadecimal
function convertDecimalToBase(decimal, radix) {
    if (decimal == 0) {
        output.value = '0';
        return;
    }
    const digits = '0123456789ABCDEF';
    let result = '';
    while (decimal > 0) {
        const remainder = decimal % radix;
        result = digits[remainder] + result;
        decimal = Math.floor(decimal / radix);
    }
    output.value = result;
}

// Convert Binary, Octal, Hexadecimal to Decimal
function convertToDecimal(value, base) {
    return parseInt(value, base);
}

// Binary to other bases
function convertBinaryToOther(value, toBase) {
    const decimalValue = convertToDecimal(value, 2);
    convertDecimalToBase(decimalValue, toBase);
}

// Octal to other bases
function convertOctalToOther(value, toBase) {
    const decimalValue = convertToDecimal(value, 8);
    convertDecimalToBase(decimalValue, toBase);
}

// Hexadecimal to other bases
function convertHexadecimalToOther(value, toBase) {
    const decimalValue = convertToDecimal(value, 16);
    convertDecimalToBase(decimalValue, toBase);
}

// Event listener for conversion
convertBtn.addEventListener('click', () => {
    const fromBase = selectFrom.value;
    const toBase = selectTo.value;
    const inputValue = inputFrom.value;

    if (fromBase === 'Decimal') {
        // Decimal to Binary, Octal, Hexadecimal
        if (toBase === 'Binary') {
            convertDecimalToBase(parseInt(inputValue), 2);
        } else if (toBase === 'Octadecimal') {
            convertDecimalToBase(parseInt(inputValue), 8);
        } else if (toBase === 'Hexadecimal') {
            convertDecimalToBase(parseInt(inputValue), 16);
        } else {
            output.value = inputValue; // Decimal to Decimal
        }
    } else if (fromBase === 'Binary') {
        // Binary to Decimal, Octal, Hexadecimal
        if (toBase === 'Decimal') {
            output.value = convertToDecimal(inputValue, 2);
        } else if (toBase === 'Octadecimal') {
            convertBinaryToOther(inputValue, 8);
        } else if (toBase === 'Hexadecimal') {
            convertBinaryToOther(inputValue, 16);
        }
    } else if (fromBase === 'Octadecimal') {
        // Octal to Decimal, Binary, Hexadecimal
        if (toBase === 'Decimal') {
            output.value = convertToDecimal(inputValue, 8);
        } else if (toBase === 'Binary') {
            convertOctalToOther(inputValue, 2);
        } else if (toBase === 'Hexadecimal') {
            convertOctalToOther(inputValue, 16);
        }
    } else if (fromBase === 'Hexadecimal') {
        // Hexadecimal to Decimal, Binary, Octal
        if (toBase === 'Decimal') {
            output.value = convertToDecimal(inputValue, 16);
        } else if (toBase === 'Binary') {
            convertHexadecimalToOther(inputValue, 2);
        } else if (toBase === 'Octadecimal') {
            convertHexadecimalToOther(inputValue, 8);
        }
    }
});



cancel.addEventListener('click', function() {
    inputFrom.value = '';
});



